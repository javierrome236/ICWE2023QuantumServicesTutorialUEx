# Amazon Braket Algorithm Library Notebooks
The Braket Algorithm Library Notebooks provide ready-to-run example notebooks of the algorithm implementations in this repo.

## Local Setup
Running notebooks locally requires the following steps:
1. pip install -r requirements.txt
2. jupyter notebook

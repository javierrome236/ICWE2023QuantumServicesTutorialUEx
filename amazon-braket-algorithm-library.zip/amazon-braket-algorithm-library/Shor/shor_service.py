from flask import Flask, jsonify, request
from braket.devices import LocalSimulator
from braket.aws import AwsDevice
from braket.experimental.algorithms.shors.shors import (
    shors_algorithm,
    run_shors_algorithm,
    get_factors_from_results
)
# Use Braket SDK Cost Tracking to estimate the cost to run this example
from braket.tracking import Tracker
tracker = Tracker().start()

app = Flask(__name__)

def shor(N, a):
# N = Integer to factor (currently 15, 21, 35 work)
# a = Any integer that satisfies 1 < a < N and gcd(a, N) = 1.


    shors_circuit = shors_algorithm(N, a)

    local_simulator = LocalSimulator()

    output = run_shors_algorithm(shors_circuit, local_simulator)

    guessed_factors = get_factors_from_results(output, N, a)

    return (guessed_factors)

@app.route('/shor_simulator', methods=['GET'])
def shor_simulator():
    N = int(request.args.get('N'))
    a = int(request.args.get('a'))
    response = shor(N, a)

    return jsonify(str(response))

@app.route('/shor_simulator_sv1', methods=['GET'])
def shor_simulator_sv1():
    N = int(request.args.get('N'))
    a = int(request.args.get('a'))
    shors_circuit = shors_algorithm(N, a)
    managed_sim = AwsDevice("arn:aws:braket:::device/quantum-simulator/amazon/sv1")
    output = run_shors_algorithm(shors_circuit, managed_sim)
    guessed_factors = get_factors_from_results(output, N, a)

    return jsonify(str(guessed_factors))

if __name__ == '__main__':
    #shor(15, 7)
    app.run(debug=False, port=8080)
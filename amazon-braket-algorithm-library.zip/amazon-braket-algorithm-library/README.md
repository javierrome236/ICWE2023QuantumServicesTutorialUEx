# Amazon Braket Algorithm Library
## <a name="install">Installing the Amazon Braket Algorithm Library</a>
The Amazon Braket Algorithm Library can be installed from source by cloning this repository and running a pip install command in the root directory of the repository.

```bash
pip install .
```

To run the Shor service

```bash
python shor_service.py
```